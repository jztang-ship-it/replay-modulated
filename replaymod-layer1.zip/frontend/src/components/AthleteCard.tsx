// src/components/AthleteCard.tsx
// LAYER 1: Card component with three visual states
//
// STATES:
// 1. "facedown" - Generic back (mystery card before reveal)
// 2. "faceup" - Player front visible
// 3. "stats" - Stats back visible (tap to view during RESULTS)
//
// TRANSITIONS:
// - facedown → faceup: Reveal animation (controlled by reveal engine)
// - faceup ↔ stats: User tap during RESULTS phase

import React, { useMemo } from "react";
import type { GamePhase, PlayerCard } from "../adapters/types";
import { AthleteCardFront } from "./AthleteCardFront";
import { CardBackGeneric } from "./CardBackGeneric";

// ============================================================
// TYPES
// ============================================================

export type CardDisplayMode = "facedown" | "faceup" | "stats";

type AthleteCardProps = {
  card: PlayerCard;
  phase: GamePhase;
  displayMode: CardDisplayMode;  // NEW: replaces isFlipped
  isFlipping?: boolean;          // NEW: true during flip animation
  isLocked: boolean;
  isMvp: boolean;
  canTapForStats: boolean;       // NEW: replaces canFlip
  onTapForStats?: () => void;    // NEW: replaces onToggleFlip

  // For badge display during reveal
  visibleBadgeCount?: number;
  visibleFp?: number;
};

// ============================================================
// HELPERS
// ============================================================

function toNum(v: any) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function prettyKey(k: string) {
  return String(k)
    .replace(/_/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .toUpperCase();
}

function pickBreakdown(card: any): Record<string, number> | null {
  const candidates = [
    card?.fpBreakdown,
    card?.pointsByStat,
    card?.fpByStat,
    card?.statFp,
    card?.scoringBreakdown,
    card?.fantasyPointsByStat,
    card?.fantasyBreakdown,
  ];

  for (const c of candidates) {
    if (!c) continue;

    if (typeof c === "object" && !Array.isArray(c)) {
      const out: Record<string, number> = {};
      for (const [k, v] of Object.entries(c)) {
        const n = Number(v);
        if (Number.isFinite(n) && n !== 0) out[String(k)] = n;
      }
      if (Object.keys(out).length) return out;
    }

    if (Array.isArray(c)) {
      const out: Record<string, number> = {};
      for (const row of c) {
        const key = row?.stat ?? row?.key ?? row?.label ?? row?.name;
        const val = row?.fp ?? row?.points ?? row?.value;
        const n = Number(val);
        if (key && Number.isFinite(n) && n !== 0) out[String(key)] = n;
      }
      if (Object.keys(out).length) return out;
    }
  }

  return null;
}

function pickStatsUsed(card: any): Record<string, any> | null {
  const candidates = [
    card?.statLine,
    card?.statsUsed,
    card?.gameInfo?.stats,
    card?.stats,
    card?.boxScore,
    card?.gameLog?.stats,
    card?.log?.stats,
  ];

  for (const s of candidates) {
    if (s && typeof s === "object" && !Array.isArray(s)) return s;
  }

  return null;
}

// ============================================================
// STATS BACK (for tap-to-view)
// ============================================================

function BackBStats({ card }: { card: PlayerCard }) {
  const anyCard: any = card;

  const breakdown = useMemo(() => pickBreakdown(anyCard), [anyCard]);
  const statsUsed = useMemo(() => pickStatsUsed(anyCard), [anyCard]);

  const breakdownRows = useMemo(() => {
    if (!breakdown) return [];
    return Object.entries(breakdown)
      .map(([k, v]) => ({ k, v }))
      .sort((a, b) => Math.abs(b.v) - Math.abs(a.v));
  }, [breakdown]);

  const statsRows = useMemo(() => {
    if (!statsUsed) return [];
    return Object.entries(statsUsed)
      .map(([k, v]) => ({ k, v }))
      .filter((r) => r.k && r.v != null && r.v !== "" && r.v !== 0)
      .slice(0, 28);
  }, [statsUsed]);

  const gi = anyCard?.gameInfo ?? {};
  const opponent = String(gi?.opponent ?? anyCard?.opponent ?? anyCard?.vs ?? anyCard?.matchup ?? "").trim();
  const ha = String(gi?.homeAway ?? anyCard?.homeAway ?? "").trim();
  const date = String(gi?.date ?? anyCard?.date ?? anyCard?.gameDate ?? anyCard?.matchDate ?? "").trim();
  const title = opponent ? `${ha === "H" ? "vs" : "@"} ${opponent}` : "Game Log";

  const fp = toNum(anyCard?.actualFp);
  const proj = toNum(anyCard?.projectedFp);

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        borderRadius: 18,
        overflow: "hidden",
        background: "linear-gradient(180deg, rgba(12,18,32,1) 0%, rgba(7,11,20,1) 100%)",
        color: "rgba(255,255,255,0.92)",
        padding: 12,
        display: "flex",
        flexDirection: "column",
        gap: 10,
        backfaceVisibility: "hidden",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: 950, letterSpacing: 0.8 }}>{title}</div>
          <div style={{ opacity: 0.75, fontSize: 12 }}>{date || " "}</div>
        </div>

        <div style={{ textAlign: "right" }}>
          <div style={{ opacity: 0.75, fontSize: 12 }}>FP</div>
          <div style={{ fontWeight: 950, fontSize: 18 }}>
            {Number.isFinite(fp) ? fp.toFixed(fp % 1 === 0 ? 0 : 1) : "0"}
          </div>
          <div style={{ opacity: 0.65, fontSize: 11 }}>
            Proj {proj.toFixed(proj % 1 === 0 ? 0 : 1)}
          </div>
        </div>
      </div>

      <div
        style={{
          borderRadius: 14,
          border: "1px solid rgba(255,255,255,0.10)",
          background: "rgba(255,255,255,0.04)",
          padding: 10,
          flex: 1,
          overflow: "auto",
        }}
      >
        <div style={{ fontWeight: 900, opacity: 0.9, marginBottom: 8 }}>FP Breakdown</div>

        {breakdownRows.length ? (
          <div style={{ display: "grid", gap: 6 }}>
            {breakdownRows.map((r) => (
              <div key={r.k} style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                <div
                  style={{
                    opacity: 0.9,
                    fontSize: 12,
                    minWidth: 0,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {prettyKey(r.k)}
                </div>
                <div style={{ fontWeight: 950, fontSize: 12, flexShrink: 0 }}>
                  {r.v > 0 ? `+${r.v}` : `${r.v}`}
                </div>
              </div>
            ))}
          </div>
        ) : statsRows.length ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6 }}>
            {statsRows.map((r) => (
              <div key={r.k} style={{ display: "flex", justifyContent: "space-between", gap: 4 }}>
                <div style={{ opacity: 0.75, fontSize: 11 }}>{prettyKey(r.k)}</div>
                <div style={{ fontWeight: 800, fontSize: 11 }}>{String(r.v)}</div>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ opacity: 0.5, fontSize: 12 }}>No stats available</div>
        )}
      </div>

      <div style={{ textAlign: "center", opacity: 0.4, fontSize: 10 }}>Tap to flip back</div>
    </div>
  );
}

// ============================================================
// MAIN COMPONENT
// ============================================================

export function AthleteCard({
  card,
  phase,
  displayMode,
  isFlipping,
  isLocked,
  isMvp,
  canTapForStats,
  onTapForStats,
  visibleBadgeCount,
  visibleFp,
}: AthleteCardProps) {
  // facedown/stats show back (rotateY 180), faceup show front (0)
  const rotation = displayMode === "faceup" ? 0 : 180;

  const flipContainer: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100%",
    perspective: "1000px",
    cursor: canTapForStats && displayMode !== "facedown" ? "pointer" : "default",
  };

  const flipInner: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100%",
    transformStyle: "preserve-3d",
    transition: isFlipping
      ? "transform 600ms cubic-bezier(.2,.85,.4,1)"
      : "transform 400ms cubic-bezier(.2,.9,.2,1)",
    transform: `rotateY(${rotation}deg)`,
  };

  const faceFront: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    backfaceVisibility: "hidden",
  };

  const faceBack: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    transform: "rotateY(180deg)",
    backfaceVisibility: "hidden",
  };

  // ✅ CRITICAL FIX: stop bubbling so RosterGrid wrapper doesn't also toggle
  const handleClick = (e: React.MouseEvent) => {
    if (canTapForStats && displayMode !== "facedown") {
      e.stopPropagation();
      onTapForStats?.();
    }
  };

  return (
    <div style={flipContainer} onClick={handleClick}>
      <div style={flipInner}>
        <div style={faceFront}>
          <AthleteCardFront
            card={card}
            phase={phase}
            isLocked={isLocked}
            isMvp={isMvp}
            isFlipped={displayMode === "stats"}
            canFlip={canTapForStats}
            onToggleFlip={onTapForStats || (() => {})}
            visibleFp={visibleFp}
            visibleBadgeCount={visibleBadgeCount}
          />
        </div>

        <div style={faceBack}>
          {displayMode === "facedown" ? <CardBackGeneric isFlipping={isFlipping} /> : <BackBStats card={card} />}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// BACKWARD COMPATIBILITY WRAPPER
// ============================================================

export type LegacyAthleteCardProps = {
  card: PlayerCard;
  phase: GamePhase;
  isLocked: boolean;
  isMvp: boolean;
  isFlipped: boolean;
  canFlip: boolean;
  onToggleFlip: () => void;
  isFaceDown?: boolean;
  visibleFp?: number;
};

export function AthleteCardLegacy({
  card,
  phase,
  isLocked,
  isMvp,
  isFlipped,
  canFlip,
  onToggleFlip,
  isFaceDown,
  visibleFp,
}: LegacyAthleteCardProps) {
  let displayMode: CardDisplayMode = "faceup";

  if (isFaceDown) displayMode = "facedown";
  else if (isFlipped) displayMode = "stats";

  return (
    <AthleteCard
      card={card}
      phase={phase}
      displayMode={displayMode}
      isFlipping={isFaceDown}
      isLocked={isLocked}
      isMvp={isMvp}
      canTapForStats={canFlip && !isFaceDown}
      onTapForStats={onToggleFlip}
      visibleFp={visibleFp}
    />
  );
}
