// src/components/CardBackGeneric.tsx
// LAYER 1: Generic face-down card back (mystery state before reveal)
//
// Shows during:
// - Initial deal animation (before player revealed)
// - After DRAW pressed (non-held cards show this, then flip to new player)

import React from "react";

type Props = {
  isFlipping?: boolean;  // True during flip animation
};

export function CardBackGeneric({ isFlipping }: Props) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        borderRadius: 18,
        overflow: "hidden",
        background: "linear-gradient(145deg, #1a1f2e 0%, #0d1117 100%)",
        border: "2px solid rgba(255,255,255,0.08)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        boxShadow: isFlipping 
          ? "0 20px 40px rgba(0,0,0,0.5), 0 0 30px rgba(100,150,255,0.15)"
          : "0 8px 24px rgba(0,0,0,0.3)",
        transition: "box-shadow 300ms ease",
      }}
    >
      {/* Subtle pattern overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 0.03,
          backgroundImage: `repeating-linear-gradient(
            45deg,
            transparent,
            transparent 10px,
            rgba(255,255,255,0.5) 10px,
            rgba(255,255,255,0.5) 11px
          )`,
        }}
      />

      {/* Center logo/branding area */}
      <div
        style={{
          position: "relative",
          width: 80,
          height: 80,
          borderRadius: "50%",
          background: "linear-gradient(135deg, rgba(100,150,255,0.15) 0%, rgba(100,150,255,0.05) 100%)",
          border: "2px solid rgba(100,150,255,0.2)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 4px 20px rgba(100,150,255,0.1)",
        }}
      >
        {/* Question mark or logo */}
        <span
          style={{
            fontSize: 36,
            fontWeight: 900,
            color: "rgba(100,150,255,0.4)",
            fontStyle: "italic",
          }}
        >
          ?
        </span>
      </div>

      {/* Bottom branding text */}
      <div
        style={{
          position: "absolute",
          bottom: 16,
          left: 0,
          right: 0,
          textAlign: "center",
        }}
      >
        <div
          style={{
            fontSize: 10,
            fontWeight: 800,
            letterSpacing: 3,
            color: "rgba(255,255,255,0.15)",
            textTransform: "uppercase",
          }}
        >
          ReplayMod
        </div>
      </div>

      {/* Corner decorations */}
      <div style={{ position: "absolute", top: 12, left: 12, opacity: 0.1 }}>
        <CornerDecoration />
      </div>
      <div style={{ position: "absolute", top: 12, right: 12, opacity: 0.1, transform: "scaleX(-1)" }}>
        <CornerDecoration />
      </div>
      <div style={{ position: "absolute", bottom: 12, left: 12, opacity: 0.1, transform: "scaleY(-1)" }}>
        <CornerDecoration />
      </div>
      <div style={{ position: "absolute", bottom: 12, right: 12, opacity: 0.1, transform: "scale(-1)" }}>
        <CornerDecoration />
      </div>
    </div>
  );
}

function CornerDecoration() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path
        d="M0 0 L20 0 L20 4 L4 4 L4 20 L0 20 Z"
        fill="rgba(255,255,255,0.5)"
      />
    </svg>
  );
}
