import React, { useEffect, useMemo, useState } from "react";
import type { GamePhase, PlayerCard } from "../adapters/types";

function clampText(v: any) {
  return String(v ?? "").trim();
}

function initialsFromName(name: string) {
  const parts = name.split(/\s+/).filter(Boolean);
  const a = parts[0]?.[0] ?? "";
  const b = parts[1]?.[0] ?? parts[0]?.[1] ?? "";
  return (a + b).toUpperCase();
}

function formatSeasonRange(season: any): string {
  const s = clampText(season);

  // 2024-2025 => 24-25
  let m = s.match(/(\d{4})\D+(\d{4})/);
  if (m) return `${m[1].slice(2)}-${m[2].slice(2)}`;

  // 24-25 => 24-25
  m = s.match(/(\d{2})\D+(\d{2})/);
  if (m) return `${m[1]}-${m[2]}`;

  // 2024 => 24-25
  m = s.match(/(\d{4})/);
  if (m) {
    const a = m[1].slice(2);
    const b = String((Number(a) + 1) % 100).padStart(2, "0");
    return `${a}-${b}`;
  }

  return s;
}

function safeKeyFor(card: any) {
  const base = String(card?.basePlayerId ?? "").trim();
  const season = String(card?.season ?? "").trim();
  return `${base}|${season}`;
}

function buildHeadshotCandidates(card: any, safeCode?: string | null): string[] {
  const out: string[] = [];

  const addUnique = (url: string | undefined | null) => {
    const u = clampText(url);
    if (!u) return;
    if (!out.includes(u)) out.push(u);
  };

  // ✅ SAFE photo code (only if safe for THIS player)
  const codeRaw = clampText(safeCode);

  // 1) Local first (SAFE ONLY)
  if (codeRaw) {
    addUnique(`/headshots/${codeRaw}.png`);
  }

  // 2) Direct URL next (always allowed)
  const direct =
    card?.headshotUrl ||
    card?.photoUrl ||
    card?.imageUrl ||
    card?.image ||
    card?.portraitUrl ||
    card?.headshot ||
    card?.img ||
    card?.player?.headshotUrl ||
    card?.player?.photoUrl ||
    card?.player?.imageUrl ||
    card?.player?.portraitUrl ||
    card?.player?.image;

  addUnique(direct);

  // 3) Remote fallbacks last (SAFE ONLY)
  if (codeRaw) {
    const codeNoP = codeRaw.replace(/^p/i, "");
    const pcode = `p${codeNoP}`;

    addUnique(`https://resources.premierleague.com/premierleague/photos/players/250x250/${pcode}.png`);
    addUnique(`https://resources.premierleague.com/premierleague/photos/players/110x140/${pcode}.png`);
    addUnique(`https://resources.premierleague.com/premierleague/photos/players/120x120/${pcode}.png`);
  }

  return out;
}







function tierTheme(tierRaw: any) {
  const t = String(tierRaw ?? "").toUpperCase();

  // slightly stronger than before so border reads clearly
  const base = { frame: "rgba(120,150,255,0.90)", glow: "rgba(120,150,255,0.22)" };

  if (t.includes("PURPLE")) return { frame: "rgba(170,110,255,0.92)", glow: "rgba(170,110,255,0.26)" };
  if (t.includes("GREEN")) return { frame: "rgba(70,210,130,0.92)", glow: "rgba(70,210,130,0.24)" };
  if (t.includes("ORANGE")) return { frame: "rgba(255,170,70,0.94)", glow: "rgba(255,170,70,0.26)" };
  if (t.includes("BLUE")) return { frame: "rgba(80,160,255,0.92)", glow: "rgba(80,160,255,0.24)" };
  if (t.includes("WHITE")) return { frame: "rgba(255,255,255,0.72)", glow: "rgba(255,255,255,0.16)" };

  return base;
}

/** Always keep year fully visible by truncating team first. */
function teamYearLine(team: string, seasonFmt: string, maxTeamChars = 14) {
  const t = clampText(team).toUpperCase();
  const y = clampText(seasonFmt);
  if (!t) return y;
  if (t.length <= maxTeamChars) return `${t} • ${y}`;
  return `${t.slice(0, Math.max(0, maxTeamChars - 1))}… • ${y}`;
}

export function AthleteCardFront(props: {
  card: PlayerCard;
  phase: GamePhase;
  isLocked: boolean;
  isMvp: boolean;
  isFlipped: boolean;
  canFlip: boolean;
  onToggleFlip: () => void;
  // For emotional reveal
  visibleFp?: number;
  visibleBadgeCount?: number;
  isRevealing?: boolean;  // True when this card is in reveal animation
}) {
  const { card, phase, isLocked, visibleFp, } = props;

  const name = clampText((card as any)?.name);
  const team = clampText((card as any)?.team);
  const season = (card as any)?.season ?? (card as any)?.year ?? (card as any)?.seasonLabel;
  const seasonFmt = formatSeasonRange(season);

  const posRaw = clampText((card as any)?.position);
  const pos = posRaw ? posRaw.slice(0, 2).toUpperCase() : "";

  const salary = Number((card as any)?.salary ?? 0);

  const showResults = phase === "RESULTS";
  const proj = Number((card as any)?.projectedFp ?? 0);
  const actual = Number((card as any)?.actualFp ?? 0);

  // Rolling FP animation state
  const [displayedFp, setDisplayedFp] = useState(proj);
  const [isRolling, setIsRolling] = useState(false);

// ================= SAFE HEADSHOT MAP =================
const [safeMap, setSafeMap] = useState<Record<string, string> | null>(null);

useEffect(() => {
  let alive = true;

  fetch("/headshots/safe-headshot-map.json")
    .then((r) => (r.ok ? r.json() : {}))
    .then((json) => {
      if (alive) setSafeMap(json ?? {});
    })
    .catch(() => {
      if (alive) setSafeMap({});
    });

  return () => {
    alive = false;
  };
}, []);

// -------------------- REVEAL FP ROLL --------------------
// When visibleFp changes during reveal, animate the roll
useEffect(() => {
  if (visibleFp === undefined) {
    setDisplayedFp(showResults ? actual : proj);
    return;
  }

  // If we have a target FP to roll to
  if (visibleFp > 0 && displayedFp !== visibleFp) {
    setIsRolling(true);

    const startValue = displayedFp;
    const endValue = visibleFp;
    const duration = 500; // ms for roll animation
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Ease out cubic for smooth deceleration
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = startValue + (endValue - startValue) * eased;

      setDisplayedFp(current);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setDisplayedFp(endValue);
        setIsRolling(false);
      }
    };

    requestAnimationFrame(animate);
  }
}, [visibleFp, showResults, actual, proj, displayedFp]);

// Calculate if reveal has completed for this card
const hasRevealed = visibleFp !== undefined && !isRolling;

// Performance headline logic
// Only show after reveal, and only if we have valid projected FP
const getPerformanceHeadline = (): { text: string; color: string; animation: string } | null => {
  if (!hasRevealed || proj <= 0) return null;

  const ratio = actual / proj;

  if (ratio > 1.40) {
    return {
      text: "🚀 CAREER NIGHT",
      color: "rgba(255, 215, 0, 0.95)",
      animation: "headlinePop",
    };
  }
  if (ratio > 1.15) {
    return {
      text: "🔥 ON FIRE",
      color: "rgba(255, 140, 50, 0.95)",
      animation: "headlinePop",
    };
  }
  if (ratio <= 0.70) {
    return {
      text: "🥶 ICE COLD",
      color: "rgba(130, 180, 220, 0.95)",
      animation: "headlineDrop",
    };
  }

  return null;
};

const headline = getPerformanceHeadline();

// Determine what to show (front big number + label)
//
// HOLD: show projected
// RESULTS: show rolling value if reveal is in-progress (visibleFp provided), otherwise final actual
const fpValue = showResults ? (visibleFp !== undefined ? displayedFp : actual) : proj;

const label = showResults ? "FP" : "PROJ";

const valueText = Number.isFinite(fpValue) ? fpValue.toFixed(fpValue % 1 === 0 ? 0 : 1) : "0";

const first = useMemo(() => {
  const parts = name.split(/\s+/).filter(Boolean);
  return clampText(parts[0] ?? "");
}, [name]);

const last = useMemo(() => {
  const parts = name.split(/\s+/).filter(Boolean);
  return clampText(parts.slice(1).join(" ") || parts[0] || "");
}, [name]);

// -------------------- SAFE HEADSHOT PICKING --------------------
// stable identity for the card (prevents wrong reset behavior)
const cardKey = useMemo(() => safeKeyFor(card), [card]);

// safeCode comes ONLY from safe-headshot-map.json (prevents collisions / wrong faces)
const safeCode = useMemo(() => {
  if (!safeMap) return null;
  return safeMap[cardKey] ?? null;
}, [safeMap, cardKey]);

// candidates are built from SAFE code + any direct URL + remote fallbacks (only if safe)
const candidates = useMemo(() => {
  return buildHeadshotCandidates(card, safeCode);
}, [card, safeCode]);

// DEV log: runs ONLY when candidates change (not every render)
useEffect(() => {
  if (import.meta.env.DEV) {
    console.log("[HEADSHOT]", (card as any)?.name, { cardKey, safeCode, candidates });
  }
}, [cardKey, safeCode, candidates, card]);

const [idx, setIdx] = useState(0);

// reset fallback index when the *card identity* changes (not just photoCode)
useEffect(() => {
  setIdx(0);
}, [cardKey]);

const headshotSrc = candidates[idx] ?? "";


  const initials = initialsFromName(name || `${team} ${pos}`);
  const tier = tierTheme((card as any)?.tier);

  // -------------------- TUNING (ONLY WHAT YOU ASKED) --------------------
  const CORNER_PAD = 8;
  const DOCK_BORDER_SAFE = 6;

  // heads down
  const HEAD_SHIFT_PX = 18;

  // dock close to bottom
  const DOCK_BOTTOM_GAP = 4;
  const DOCK_HEIGHT = "24%";
  const ROW_GAP = 1;

  // -------------------- STYLES --------------------
  const cardShell: React.CSSProperties = {
    position: "relative",
    width: "100%",
    height: "100%",
    borderRadius: 18,
    overflow: "hidden",
    background: "linear-gradient(180deg, #0B1220 0%, #070B14 100%)",
    border: `2px solid ${tier.frame}`,
    boxShadow: "0 18px 40px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.08) inset",
  };

  const tierGlow: React.CSSProperties = {
    position: "absolute",
    inset: -40,
    pointerEvents: "none",
    background: `radial-gradient(closest-side at 20% 15%, ${tier.glow} 0%, rgba(0,0,0,0) 70%)`,
    opacity: 0.55,
  };

  const topStrip: React.CSSProperties = {
    position: "absolute",
    top: CORNER_PAD,
    left: CORNER_PAD,
    right: CORNER_PAD,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    zIndex: 6,
    pointerEvents: "none",
  };

  const salaryTag: React.CSSProperties = {
    padding: "6px 10px",
    borderRadius: 12,
    background: "rgba(15,18,24,0.55)",
    border: "1px solid rgba(255,255,255,0.14)",
    color: "rgba(255,255,255,0.95)",
    fontWeight: 950,
    fontSize: 12,
    letterSpacing: 0.6,
    backdropFilter: "blur(10px)",
  };

  // HOLD triangle (yellow) with centered H
  const holdTri: React.CSSProperties = {
    position: "absolute",
    top: 0,
    left: 0,
    width: 0,
    height: 0,
    borderTop: "42px solid rgba(245,200,80,0.95)",
    borderRight: "42px solid transparent",
    zIndex: 7,
    pointerEvents: "none",
  };

  const holdText: React.CSSProperties = {
    position: "absolute",
    top: 14,
    left: 14,
    transform: "translate(-50%, -50%)",
    zIndex: 8,
    pointerEvents: "none",
    fontSize: 12,
    fontWeight: 950,
    color: "rgba(0,0,0,0.92)",
  };

  const heroWrap: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    zIndex: 1,
  };

  const heroMask: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    borderRadius: 18,
    overflow: "hidden",
    transform: "translateZ(0)",
  };

  const heroImage: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    width: "100%",
    height: "100%",
    objectFit: "cover",
    objectPosition: "50% 0%",
    transform: `translateY(${HEAD_SHIFT_PX}px) scale(1.03)`,
  };

  const heroShade: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    pointerEvents: "none",
    background:
      "radial-gradient(110% 85% at 50% 20%, rgba(0,0,0,0.00) 0%, rgba(0,0,0,0.10) 60%, rgba(0,0,0,0.30) 100%)",
  };

  const placeholder: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    display: "grid",
    placeItems: "center",
    fontSize: 68,
    fontWeight: 950,
    letterSpacing: 2,
    color: "rgba(255,255,255,0.70)",
    textShadow: "0 10px 30px rgba(0,0,0,0.60)",
    userSelect: "none",
  };

  const dock: React.CSSProperties = {
    position: "absolute",
    left: DOCK_BORDER_SAFE,
    right: DOCK_BORDER_SAFE,
    bottom: DOCK_BOTTOM_GAP,
    height: DOCK_HEIGHT,

    borderRadius: 18,
    padding: "6px 12px",

    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    gap: 10,

    background: "linear-gradient(180deg, rgba(255,255,255,0.08), rgba(0,0,0,0.62))",

    borderTop: "1px solid rgba(255,255,255,0.10)",
    borderBottom: "1px solid rgba(255,255,255,0.08)",
    borderLeft: "0px solid transparent",
    borderRight: "0px solid transparent",

    boxShadow: "0 10px 22px rgba(0,0,0,0.28)",
    backdropFilter: "blur(12px)",
    zIndex: 6,
  };

  const shadowText = "0 2px 8px rgba(0,0,0,0.55)";

  const teamLine: React.CSSProperties = {
    fontSize: 9,
    fontWeight: 900,
    letterSpacing: 1.0,
    textTransform: "uppercase",
    opacity: 0.9,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    textShadow: shadowText,
    textAlign: "center",
    lineHeight: "1.05",
  };

  const firstLine: React.CSSProperties = {
    fontSize: 10,
    fontWeight: 900,
    letterSpacing: 0.6,
    textTransform: "uppercase",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    textShadow: shadowText,
    textAlign: "left",
    lineHeight: "1.05",
  };

  const lastLine: React.CSSProperties = {
    fontSize: 13,
    fontWeight: 950,
    letterSpacing: 0.8,
    textTransform: "uppercase",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    textShadow: shadowText,
    textAlign: "left",
    lineHeight: "1.05",
  };

  const posLine: React.CSSProperties = {
    fontSize: 10,
    fontWeight: 900,
    letterSpacing: 0.6,
    textTransform: "uppercase",
    textShadow: shadowText,
    opacity: 0.95,
    lineHeight: "1.05",
  };

  const labelLine: React.CSSProperties = {
    fontSize: 9,
    fontWeight: 900,
    letterSpacing: 1.0,
    textShadow: shadowText,
    opacity: 0.75,
    lineHeight: "1.05",
  };

  const valueLine: React.CSSProperties = {
    fontSize: 12,
    fontWeight: 950,
    letterSpacing: 0.2,
    textShadow: shadowText,
    opacity: 0.98,
    lineHeight: "1.05",
  };

  const teamSeason = teamYearLine(team, seasonFmt, 14);

  const showHoldIndicator = isLocked || (card as any).wasHeld;

  return (
    <div style={cardShell}>
      <div style={tierGlow} />

      {showHoldIndicator ? (
        <>
          <div style={holdTri} />
          <div style={holdText}>H</div>
        </>
      ) : null}

      <div style={topStrip}>
        <div />
        <div style={salaryTag}>${salary}</div>
      </div>

      <div style={heroWrap}>
        <div style={heroMask}>
          {headshotSrc ? (
            <img
              key={headshotSrc}
              src={headshotSrc}
              alt={name}
              style={heroImage}
              draggable={false}
              referrerPolicy="no-referrer"
              onError={() => {
                if (idx < candidates.length - 1) setIdx((v) => v + 1);
                else setIdx(candidates.length);
              }}
            />
          ) : (
            <div style={placeholder}>{initials}</div>
          )}
          <div style={heroShade} />
        </div>
      </div>

      <div style={dock}>
        <div style={{ minWidth: 0, flex: 1, display: "flex", flexDirection: "column", gap: ROW_GAP }}>
          <div style={teamLine}>{teamSeason}</div>

          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10 }}>
            <div style={{ ...firstLine, minWidth: 0, flex: 1 }}>{first}</div>
            <div style={posLine}>{pos}</div>
          </div>

          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10 }}>
            <div style={{ ...lastLine, minWidth: 0, flex: 1 }}>{last}</div>
            <div style={{ display: "flex", alignItems: "baseline", gap: 6, flexShrink: 0 }}>
              <div style={labelLine}>{label}</div>
              <div style={{
                ...valueLine,
                transition: isRolling ? "none" : "transform 150ms ease",
                transform: isRolling ? "scale(1.05)" : "scale(1)",
              }}>{valueText}</div>
            </div>
          </div>
          
          {/* Performance Headline */}
          {headline && (
            <div
              style={{
                fontSize: 9,
                fontWeight: 900,
                letterSpacing: 0.8,
                color: headline.color,
                textAlign: "center",
                textShadow: "0 1px 3px rgba(0,0,0,0.5)",
                marginTop: 2,
                opacity: 1,
                transform: headline.animation === "headlinePop" 
                  ? "scale(1) translateY(0)" 
                  : "scale(1) translateY(0)",
                transition: "opacity 0.3s ease, transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)",
              }}
            >
              {headline.text}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}