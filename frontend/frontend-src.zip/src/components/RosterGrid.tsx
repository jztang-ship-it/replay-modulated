import { useMemo } from "react";
import type { GamePhase, PlayerCard } from "../adapters/types";
import { CardSlot } from "./CardSlot";

function cardKey(c: any): string {
  return String(c?.cardId ?? c?.id ?? c?.playerId ?? c?.basePlayerId ?? c?.uid ?? c?.name ?? "");
}

export function RosterGrid(props: {
  roster: PlayerCard[];
  phase: GamePhase;
  lockedIds: Set<string>;
  mvpId?: string;
  flippedIds: Set<string>;
  onToggleLock: (cardKey: string) => void;
  onToggleFlip: (cardKey: string) => void;
  columns?: 2 | 3;
  canFlip?: boolean;
}) {
  const { roster, phase, lockedIds, mvpId, flippedIds, onToggleLock, onToggleFlip, columns, canFlip } = props;

  const cols = useMemo(() => {
    if (columns) return columns;
    if (typeof window === "undefined") return 2;
    return window.matchMedia?.("(min-width: 900px)")?.matches ? 3 : 2;
  }, [columns]);

  // FIXED: Use slotIndex to maintain correct slot order
  // Don't sort by position - that causes cards to jump!
  const sortedCards = useMemo(() => {
    return [...roster].sort((a, b) => (a.slotIndex ?? 0) - (b.slotIndex ?? 0));
  }, [roster]);

  const allowFlip = canFlip ?? phase === "RESULTS";

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        overflow: "hidden",
        display: "grid",
        gap: 10,
        gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
        gridAutoRows: "1fr",
        alignContent: "stretch",
      }}
    >
      {sortedCards.map((card) => {
        const key = cardKey(card);
        return (
          <CardSlot
            key={key}
            card={card}
            phase={phase}
            isLocked={lockedIds.has(key)}
            isMvp={mvpId === key}
            isFlipped={flippedIds.has(key)}
            canFlip={allowFlip}
            onToggleLock={() => onToggleLock(key)}
            onToggleFlip={() => onToggleFlip(key)}
          />
        );
      })}
    </div>
  );
}