import React, { useMemo, useState } from "react";
import type { GamePhase, PlayerCard } from "../adapters/types";
import { dealInitialRoster, redrawRoster, resolveRoster } from "../adapters/gameAdapter";
import { RosterGrid } from "../components/RosterGrid";
import { ScoreHeader } from "../components/ScoreHeader";
import { WinCelebration } from "../components/WinCelebration";
import { useResultsReveal } from "../ui/hooks/useResultsReveal";
import { calculateWinTier, calculatePayout, type WinTier } from "../utils/payoutLogic";

const CAP_MAX = 180;
const STARTING_BALANCE = 1000;
const BASE_BET = 10;

type GameState = "IDLE" | "HOLD" | "RESULTS" | "WIN_CELEBRATION";

function cardId(card: any): string {
  const v = card?.cardId ?? card?.id ?? card?.playerId ?? card?.basePlayerId ?? card?.uid ?? card?.name;
  return String(v ?? "");
}

// ✅ FIX 1: Robust salary parsing
function salaryNum(v: any): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  const s = String(v ?? "").trim();
  const cleaned = s.replace(/[^\d.-]/g, "");
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}

function sumSalary(roster: PlayerCard[]) {
  return roster.reduce((acc, c: any) => acc + salaryNum(c?.salary), 0);
}

function sumLockedSalary(roster: PlayerCard[], lockedIds: Set<string>) {
  return roster.reduce((acc, c: any) => 
    lockedIds.has(cardId(c)) ? acc + salaryNum(c?.salary) : acc, 0
  );
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export default function GameView() {
  const [gameState, setGameState] = useState<GameState>("IDLE");
  const [roster, setRoster] = useState<PlayerCard[]>([]);
  const [lockedCardIds, setLockedCardIds] = useState<Set<string>>(new Set());
  const [flippedIds, setFlippedIds] = useState<Set<string>>(new Set());
  const [mvpId, setMvpId] = useState<string | undefined>(undefined);
  const [betMultiplier, setBetMultiplier] = useState<number>(1);
  
  const [balance, setBalance] = useState<number>(STARTING_BALANCE);
  const [isBalanceAnimating, setIsBalanceAnimating] = useState(false);
  
  // ✅ FIX 2: Separate countdown for HOLD vs REVEAL
  const [revealRemaining, setRevealRemaining] = useState<number>(CAP_MAX);
  
  const [winTier, setWinTier] = useState<WinTier | null>(null);
  const [winPayout, setWinPayout] = useState(0);

  const phase: GamePhase = useMemo(() => {
    if (gameState === "RESULTS" || gameState === "WIN_CELEBRATION") return "RESULTS";
    return "HOLD";
  }, [gameState]);

  // ✅ FIX 2: Derived countdown for HOLD phase (locked cards only)
  const holdRemaining = useMemo(() => {
    return Math.max(0, CAP_MAX - sumLockedSalary(roster, lockedCardIds));
  }, [roster, lockedCardIds]);

  const capUsed = useMemo(() => sumSalary(roster), [roster]);

  const { revealedIds, runningTotalFp, isRevealing, skipToEnd } = useResultsReveal({
    phase,
    roster,
    revealDelayMs: 450,
    order: "roster",
  });

  const displayRoster = useMemo(() => {
    if (phase !== "RESULTS") return roster;
    return roster.map((c: any) => {
      const id = cardId(c);
      if (revealedIds.has(id)) return c;
      return { ...c, actualFp: 0, fpDelta: 0, bonusFp: 0, bonusPoints: 0 } as PlayerCard;
    });
  }, [phase, roster, revealedIds]);

  const totalFp = useMemo(() => {
    if (phase === "RESULTS") return runningTotalFp;
    return roster.reduce((a, c: any) => a + Number(c?.projectedFp ?? 0), 0);
  }, [phase, roster, runningTotalFp]);

  const currentBet = BASE_BET * betMultiplier;

  function toggleLock(cardKey: string) {
    if (gameState !== "HOLD") return;
    
    setLockedCardIds((prev) => {
      const next = new Set(prev);
      if (next.has(cardKey)) {
        next.delete(cardKey);
      } else {
        next.add(cardKey);
      }
      return next;
    });
  }

  // ✅ FIX 3: Allow flipping during reveal
  function toggleFlip(cardKey: string) {
    if (phase !== "RESULTS") return;

    setFlippedIds((prev) => {
      const next = new Set(prev);
      if (next.has(cardKey)) next.delete(cardKey);
      else next.add(cardKey);
      return next;
    });
  }

  async function onPrimaryAction() {
    if (gameState === "IDLE") {
      if (balance < currentBet) {
        alert("Insufficient balance!");
        return;
      }

      setFlippedIds(new Set());
      setLockedCardIds(new Set());
      setMvpId(undefined);
      setRevealRemaining(CAP_MAX);

      const res: any = await dealInitialRoster();
      const nextRosterRaw: PlayerCard[] = (res?.roster ?? res?.cards ?? res?.lineup ?? []) as PlayerCard[];
      
      // ✅ FIX 1: Force wasHeld to false on initial deal
      const nextRoster = nextRosterRaw.map((c: any) => ({ ...c, wasHeld: false }));
      
      setRoster(nextRoster);
      setGameState("HOLD");
      return;
    }

    if (gameState === "HOLD") {
      setBalance((prev) => prev - currentBet);

      const unlocked = new Set<string>();
      for (const c of roster) {
        const id = cardId(c);
        if (!lockedCardIds.has(id)) unlocked.add(id);
      }
      setFlippedIds(unlocked);

      const BACK_BEFORE_SWAP_MS = 450;
      const BACK_AFTER_SWAP_MS = 900;
      const REVEAL_STAGGER_MS = 140;

      await sleep(BACK_BEFORE_SWAP_MS);

      const res: any = await redrawRoster({ currentCards: roster, lockedCardIds });
      const drawnRoster: PlayerCard[] =
        (res?.roster ?? res?.cards ?? res?.lineup ?? res?.finalCards ?? roster) as PlayerCard[];

      const resolveRes: any = await resolveRoster({ finalCards: drawnRoster });
      const finalRosterRaw: PlayerCard[] =
        (resolveRes?.roster ?? resolveRes?.cards ?? resolveRes?.finalCards ?? drawnRoster) as PlayerCard[];

      // ✅ FIX 1: Set wasHeld correctly based on locked status
      const finalRoster = finalRosterRaw.map((c: any, i: number) => {
        const prev = roster[i];
        const prevId = prev ? cardId(prev) : "";
        const isLocked = prevId && lockedCardIds.has(prevId);
        return { ...c, wasHeld: isLocked };
      });

      setRoster(finalRoster);
      setFlippedIds(new Set()); // Reset stale IDs

      // ✅ FIX 2: Initialize reveal countdown from HOLD remaining
      setRevealRemaining(holdRemaining);

      await sleep(BACK_AFTER_SWAP_MS);

      // Reveal one-by-one with countdown
      const revealOrder = Array.from(unlocked);
      
      for (let idx = 0; idx < revealOrder.length; idx++) {
        const id = revealOrder[idx];
        
        setFlippedIds((prev) => {
          const next = new Set(prev);
          next.delete(id);
          return next;
        });
        
        // ✅ FIX 2: Decrement reveal countdown as each new card reveals
        const slotIdx = roster.findIndex(c => cardId(c) === id);
        if (slotIdx !== -1) {
          const newSalary = salaryNum(finalRoster[slotIdx]?.salary);
          setRevealRemaining(prev => Math.max(0, prev - newSalary));
        }
        
        await sleep(REVEAL_STAGGER_MS);
      }

      // ✅ FIX 2: Snap to final truth
      setRevealRemaining(Math.max(0, CAP_MAX - sumSalary(finalRoster)));

      const maybeMvp: string | undefined = resolveRes?.mvpId ?? resolveRes?.mvpCardId ?? resolveRes?.topCardId;
      if (typeof maybeMvp === "string") setMvpId(maybeMvp);

      setGameState("RESULTS");
      
      const finalTotalFp = finalRoster.reduce((sum, c: any) => sum + Number(c?.actualFp ?? 0), 0);
      const tier = calculateWinTier(finalTotalFp);
      const payout = calculatePayout(tier, currentBet);
      
      await sleep(800);
      
      setWinTier(tier);
      setWinPayout(payout);
      setGameState("WIN_CELEBRATION");
      
      return;
    }

    // REPLAY reset
    setRoster([]);
    setLockedCardIds(new Set());
    setFlippedIds(new Set());
    setMvpId(undefined);
    setWinTier(null);
    setWinPayout(0);
    setRevealRemaining(CAP_MAX);
    setGameState("IDLE");
  }

  function onWinCelebrationComplete() {
    if (winPayout > 0) {
      setIsBalanceAnimating(true);
      setBalance((prev) => prev + winPayout);
      setTimeout(() => setIsBalanceAnimating(false), 2000);
    }
    
    setWinTier(null);
    setWinPayout(0);
  }

  const primaryButtonLabel = useMemo(() => {
    if (gameState === "IDLE") return `PLAY ($${currentBet})`;
    if (gameState === "HOLD") return "DRAW";
    if (gameState === "RESULTS" || gameState === "WIN_CELEBRATION") return "REPLAY";
    return "PLAY";
  }, [gameState, currentBet]);

  const primaryButtonStyle = useMemo(() => {
    const base: React.CSSProperties = {
      width: "50%",
      height: 48,
      margin: "0 auto",
      borderRadius: 12,
      border: "1px solid rgba(255,255,255,0.14)",
      fontWeight: 950,
      fontSize: 14,
      cursor: "pointer",
      letterSpacing: 1,
      color: "#fff",
      boxShadow: "0 10px 24px rgba(0,0,0,0.32)",
    };

    if (gameState === "HOLD") return { ...base, background: "linear-gradient(180deg, #36D46B 0%, #1FA94B 100%)" };
    if (gameState === "RESULTS" || gameState === "WIN_CELEBRATION") return { ...base, background: "linear-gradient(180deg, #3AA0FF 0%, #1D6DD7 100%)" };
    return { ...base, background: "linear-gradient(180deg, #FFB14A 0%, #FF7A2F 100%)" };
  }, [gameState]);

  const cabinetBg = useMemo(() => {
    return {
      background:
        "radial-gradient(1200px 700px at 50% 0%, rgba(60,130,255,0.18) 0%, rgba(10,14,24,0) 55%)," +
        "radial-gradient(900px 700px at 20% 10%, rgba(255,140,60,0.14) 0%, rgba(10,14,24,0) 60%)," +
        "radial-gradient(900px 700px at 80% 15%, rgba(120,255,210,0.10) 0%, rgba(10,14,24,0) 60%)," +
        "linear-gradient(180deg, #070A12 0%, #0A1020 38%, #070A12 100%)",
    } as const;
  }, []);

  return (
    <div style={{ position: "fixed", inset: 0, ...cabinetBg, overflow: "hidden", color: "#EAF0FF" }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          paddingTop: "max(env(safe-area-inset-top), 8px)",
          paddingBottom: "max(env(safe-area-inset-bottom), 10px)",
          display: "flex",
          flexDirection: "column",
          gap: 8,
        }}
      >
        <div style={{ flex: "0 0 auto", padding: "0 12px" }}>
          <div
            style={{
              borderRadius: 18,
              border: "1px solid rgba(255,255,255,0.10)",
              background: "rgba(255,255,255,0.06)",
              boxShadow: "0 14px 34px rgba(0,0,0,0.32)",
              padding: "8px 10px",
              backdropFilter: "blur(10px)",
            }}
          >
            <ScoreHeader
              totalFp={totalFp}
              capUsed={capUsed}
              capMax={CAP_MAX}
              capRemaining={phase === "RESULTS" ? revealRemaining : holdRemaining}
              phase={phase}
              subtitle={""}
              balance={balance}
              isBalanceAnimating={isBalanceAnimating}
            />
          </div>
        </div>

        <div style={{ flex: "1 1 auto", minHeight: 0, padding: "0 12px" }}>
          <div
            onClick={phase === "RESULTS" && isRevealing ? skipToEnd : undefined}
            style={{
              height: "100%",
              minHeight: 0,
              borderRadius: 18,
              border: "1px solid rgba(255,255,255,0.10)",
              background: "rgba(255,255,255,0.04)",
              boxShadow: "0 18px 60px rgba(0,0,0,0.45)",
              backdropFilter: "blur(10px)",
              padding: 10,
              overflow: "hidden",
              cursor: phase === "RESULTS" && isRevealing ? "pointer" : "default",
            }}
          >
            <RosterGrid
              roster={displayRoster}
              phase={phase}
              lockedIds={lockedCardIds}
              mvpId={mvpId}
              flippedIds={flippedIds}
              canFlip={phase === "RESULTS"}
              onToggleLock={(k) => toggleLock(k)}
              onToggleFlip={(k) => toggleFlip(k)}
            />
          </div>
        </div>

        <div style={{ flex: "0 0 auto", padding: "0 12px" }}>
          <div
            style={{
              borderRadius: 18,
              border: "1px solid rgba(255,255,255,0.10)",
              background: "rgba(255,255,255,0.06)",
              boxShadow: "0 14px 34px rgba(0,0,0,0.32)",
              padding: "8px 10px",
              backdropFilter: "blur(10px)",
            }}
          >
            <div style={{ display: "flex", gap: 10, justifyContent: "center", marginBottom: 8 }}>
              {[1, 3, 5, 10].map((mult) => {
                const active = betMultiplier === mult;
                const label = mult === 1 ? "Min" : mult === 10 ? "Max" : `${mult}x`;

                return (
                  <button
                    key={mult}
                    onClick={() => setBetMultiplier(mult)}
                    disabled={gameState !== "IDLE"}
                    style={{
                      width: 74,
                      height: 34,
                      borderRadius: 12,
                      border: active ? "1px solid rgba(100,180,255,0.8)" : "1px solid rgba(255,255,255,0.14)",
                      background: active ? "rgba(80,150,255,0.18)" : "rgba(255,255,255,0.06)",
                      color: "#EAF0FF",
                      fontWeight: active ? 950 : 800,
                      cursor: gameState === "IDLE" ? "pointer" : "not-allowed",
                      fontSize: 14,
                      opacity: gameState === "IDLE" ? 1 : 0.5,
                    }}
                  >
                    {label}
                  </button>
                );
              })}
            </div>

            <button onClick={onPrimaryAction} style={primaryButtonStyle}>
              {primaryButtonLabel}
            </button>
          </div>
        </div>
      </div>

      {gameState === "WIN_CELEBRATION" && winTier && (
        <WinCelebration
          tier={winTier}
          payout={winPayout}
          multiplier={betMultiplier}
          onComplete={onWinCelebrationComplete}
        />
      )}
    </div>
  );
}