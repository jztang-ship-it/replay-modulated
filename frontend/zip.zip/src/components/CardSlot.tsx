// frontend/src/components/CardSlot.tsx
// SIMPLIFIED VERSION - Works with indices like basketball

import React from "react";
import type { GamePhase, PlayerCard } from "../adapters/types";
import { AthleteCard } from "./AthleteCard";

type Props = {
  card: PlayerCard;
  index: number;
  phase: GamePhase;
  isHeld: boolean;
  isFlipped: boolean;
  onToggleHold: () => void;
};

export function CardSlot(props: Props) {
  const { card, phase, isHeld, isFlipped, onToggleHold } = props;
  
  const canToggle = phase === "HOLD";
  
  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        cursor: canToggle ? "pointer" : "default",
        transform: isHeld ? "scale(1.03)" : "scale(1)",
        transition: "transform 0.15s ease",
        zIndex: isHeld ? 10 : 1,
      }}
      onClick={canToggle ? onToggleHold : undefined}
    >
      <AthleteCard
        card={card}
        phase={phase}
        isHeld={isHeld}
        isFlipped={isFlipped}
      />
    </div>
  );
}
