// frontend/src/components/AthleteCard.tsx
// SIMPLIFIED VERSION - Basketball-style card with flip animation

import React, { useState, useEffect } from "react";
import type { GamePhase, PlayerCard, TierColor } from "../adapters/types";

type Props = {
  card: PlayerCard;
  phase: GamePhase;
  isHeld: boolean;
  isFlipped: boolean;
};

// Tier styling (from basketball)
function getTierStyle(tier: TierColor): { border: string; bg: string; text: string } {
  switch (tier) {
    case "ORANGE":
      return { 
        border: "2px solid #f59e0b", 
        bg: "linear-gradient(180deg, #d97706 0%, #92400e 50%, #451a03 100%)", 
        text: "#fbbf24" 
      };
    case "PURPLE":
      return { 
        border: "2px solid #a855f7", 
        bg: "linear-gradient(180deg, #9333ea 0%, #6b21a8 50%, #3b0764 100%)", 
        text: "#c084fc" 
      };
    case "BLUE":
      return { 
        border: "2px solid #3b82f6", 
        bg: "linear-gradient(180deg, #2563eb 0%, #1d4ed8 50%, #1e3a8a 100%)", 
        text: "#60a5fa" 
      };
    case "GREEN":
      return { 
        border: "2px solid #22c55e", 
        bg: "linear-gradient(180deg, #16a34a 0%, #15803d 50%, #14532d 100%)", 
        text: "#4ade80" 
      };
    default:
      return { 
        border: "2px solid #64748b", 
        bg: "linear-gradient(180deg, #475569 0%, #334155 50%, #1e293b 100%)", 
        text: "#94a3b8" 
      };
  }
}

// Score roller animation
function ScoreRoller({ value }: { value: number }) {
  const [display, setDisplay] = useState(0);
  
  useEffect(() => {
    const target = value || 0;
    let start = display;
    let startTime: number | null = null;
    const duration = 300;
    
    const animate = (time: number) => {
      if (!startTime) startTime = time;
      const progress = Math.min((time - startTime) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 4);
      setDisplay(start + (target - start) * ease);
      if (progress < 1) requestAnimationFrame(animate);
      else setDisplay(target);
    };
    
    requestAnimationFrame(animate);
  }, [value]);
  
  return <>{display.toFixed(1)}</>;
}

export function AthleteCard({ card, phase, isHeld, isFlipped }: Props) {
  const [manualFlip, setManualFlip] = useState(false);
  const tier = getTierStyle(card.tier);
  
  // Reset manual flip when card changes
  useEffect(() => {
    setManualFlip(false);
  }, [card.cardId]);
  
  const handleClick = () => {
    if (phase === "RESULTS") {
      setManualFlip(!manualFlip);
    }
  };
  
  const showBack = isFlipped || manualFlip;
  const showResult = phase === "RESULTS";
  
  // Name formatting
  const nameParts = card.name.split(" ");
  const firstName = nameParts[0] || "";
  let lastName = nameParts.slice(1).join(" ") || card.name;
  if (lastName.length > 9) lastName = lastName.substring(0, 8) + ".";
  
  // Photo URL (ESPN style)
  const photoUrl = card.photoCode 
    ? `https://a.espncdn.com/i/headshots/soccer/players/full/${card.photoCode}.png`
    : null;
  
  // Score color based on performance
  const projectedFp = card.projectedFp || card.salary * 2;  // Rough projection
  const actualFp = card.actualFp || 0;
  const scoreColor = showResult && actualFp >= projectedFp * 1.15 ? "#4ade80" 
    : showResult && actualFp <= projectedFp * 0.85 ? "#f87171" 
    : "#ffffff";

  return (
    <div
      onClick={handleClick}
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        perspective: "1000px",
        cursor: phase === "RESULTS" ? "pointer" : "default",
      }}
    >
      {/* Hold Indicator - Outside the flip */}
      {isHeld && (
        <div style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: 0,
          height: 0,
          borderTop: "36px solid #fbbf24",
          borderRight: "36px solid transparent",
          zIndex: 50,
          pointerEvents: "none",
        }}>
          <span style={{
            position: "absolute",
            top: "-30px",
            left: "6px",
            fontSize: 12,
            fontWeight: 900,
            color: "#000",
          }}>
            H
          </span>
        </div>
      )}

      {/* Flip Container */}
      <div style={{
        position: "relative",
        width: "100%",
        height: "100%",
        transformStyle: "preserve-3d",
        transition: "transform 0.4s ease",
        transform: showBack ? "rotateY(180deg)" : "rotateY(0deg)",
      }}>
        
        {/* FRONT FACE */}
        <div style={{
          position: "absolute",
          inset: 0,
          borderRadius: 16,
          border: tier.border,
          background: tier.bg,
          overflow: "hidden",
          backfaceVisibility: "hidden",
          display: "flex",
          flexDirection: "column",
        }}>
          {/* Background Image */}
          <div style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}>
            {photoUrl && (
              <img
                src={photoUrl}
                alt={card.name}
                style={{
                  width: "110%",
                  height: "auto",
                  objectFit: "cover",
                  transform: "translateY(5%)",
                  filter: "drop-shadow(0 4px 8px rgba(0,0,0,0.5))",
                }}
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = "none";
                }}
              />
            )}
            <div style={{
              position: "absolute",
              inset: 0,
              background: "linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.2) 50%, transparent 100%)",
            }} />
          </div>

          {/* Content Overlay */}
          <div style={{
            position: "relative",
            zIndex: 10,
            width: "100%",
            height: "100%",
            padding: 8,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}>
            {/* Top: Position & Cost */}
            <div style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
            }}>
              <div style={{
                background: "rgba(0,0,0,0.7)",
                padding: "2px 6px",
                borderRadius: 4,
                fontSize: 10,
                fontWeight: 900,
                color: tier.text,
              }}>
                {card.position}
              </div>
              <div style={{
                fontSize: 14,
                fontWeight: 900,
                color: "#fff",
                textShadow: "0 2px 4px rgba(0,0,0,0.8)",
              }}>
                ${card.salary}
              </div>
            </div>

            {/* Bottom: Name & Score */}
            <div style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-end",
            }}>
              {/* Name */}
              <div style={{
                flex: 1,
                overflow: "hidden",
                paddingRight: 8,
              }}>
                <div style={{
                  fontSize: 9,
                  fontWeight: 700,
                  color: "rgba(255,255,255,0.6)",
                  textTransform: "uppercase",
                  letterSpacing: 0.5,
                }}>
                  {card.team}
                </div>
                {firstName && (
                  <div style={{
                    fontSize: 10,
                    fontWeight: 700,
                    color: "rgba(255,255,255,0.8)",
                    textTransform: "uppercase",
                  }}>
                    {firstName}
                  </div>
                )}
                <div style={{
                  fontSize: 16,
                  fontWeight: 900,
                  fontStyle: "italic",
                  color: "#fff",
                  textTransform: "uppercase",
                  letterSpacing: -0.5,
                  lineHeight: 1,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}>
                  {lastName}
                </div>
              </div>

              {/* Score */}
              <div style={{ textAlign: "right" }}>
                <div style={{
                  fontSize: 8,
                  fontWeight: 900,
                  color: showResult ? "rgba(255,255,255,0.6)" : "#eab308",
                  textTransform: "uppercase",
                  letterSpacing: 1,
                }}>
                  {showResult ? "FP" : "PROJ"}
                </div>
                <div style={{
                  fontSize: 18,
                  fontWeight: 900,
                  fontFamily: "monospace",
                  color: scoreColor,
                  lineHeight: 1,
                }}>
                  <ScoreRoller value={showResult ? actualFp : projectedFp} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* BACK FACE */}
        <div style={{
          position: "absolute",
          inset: 0,
          borderRadius: 16,
          border: "2px solid #334155",
          background: "linear-gradient(180deg, #1e293b 0%, #0f172a 100%)",
          overflow: "hidden",
          backfaceVisibility: "hidden",
          transform: "rotateY(180deg)",
          padding: 8,
          display: "flex",
          flexDirection: "column",
        }}>
          {/* Header */}
          <div style={{
            borderBottom: "1px solid rgba(255,255,255,0.1)",
            paddingBottom: 6,
            marginBottom: 6,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}>
            <div style={{
              fontSize: 11,
              fontWeight: 900,
              color: "#fff",
              fontStyle: "italic",
              textTransform: "uppercase",
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
              maxWidth: "70%",
            }}>
              {card.name}
            </div>
            <div style={{
              fontSize: 9,
              fontWeight: 700,
              color: "rgba(255,255,255,0.5)",
            }}>
              {card.team}
            </div>
          </div>

          {/* FP Display */}
          <div style={{
            background: "rgba(0,0,0,0.3)",
            borderRadius: 8,
            padding: "6px 10px",
            marginBottom: 6,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}>
            <span style={{ fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.6)" }}>FP</span>
            <span style={{ fontSize: 16, fontWeight: 900, color: scoreColor, fontFamily: "monospace" }}>
              {actualFp.toFixed(1)}
            </span>
          </div>

          {/* Game Info */}
          {card.gameInfo && (
            <div style={{
              textAlign: "center",
              marginBottom: 6,
              fontSize: 9,
              color: "rgba(255,255,255,0.5)",
            }}>
              {card.gameInfo.homeAway === "H" ? "vs" : "@"} {card.gameInfo.opponent || "OPP"} • {card.gameInfo.date || ""}
            </div>
          )}

          {/* Stats Grid */}
          <div style={{
            flex: 1,
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 4,
          }}>
            {Object.entries(card.statLine || {}).slice(0, 6).map(([key, value]) => (
              <div key={key} style={{
                background: "rgba(0,0,0,0.3)",
                borderRadius: 6,
                padding: 4,
                textAlign: "center",
              }}>
                <div style={{ fontSize: 7, fontWeight: 700, color: "rgba(255,255,255,0.5)", textTransform: "uppercase" }}>
                  {key.substring(0, 3)}
                </div>
                <div style={{ fontSize: 11, fontWeight: 900, color: "#fff", fontFamily: "monospace" }}>
                  {String(value)}
                </div>
              </div>
            ))}
          </div>

          {/* Tap hint */}
          <div style={{
            textAlign: "center",
            marginTop: 6,
            fontSize: 9,
            color: "rgba(255,255,255,0.4)",
          }}>
            Tap to flip
          </div>
        </div>
      </div>
    </div>
  );
}
